const resultadoEmpates =
    document.getElementById("resultadoEmpates");


obtenerPartidos()
    .then(function(datos) {

        const partidos = datos.games;


        console.log("PARTIDOS RECIBIDOS PARA EMPATES:");

        console.log(partidos);


        // Obtener solamente los partidos finalizados
        const partidosFinalizados = partidos.filter(function(partido) {

            return partido.finished === "TRUE";

        });


        // Obtener solamente los partidos empatados
        const partidosEmpatados = partidosFinalizados.filter(function(partido) {

            return Number(partido.home_score) ===
                   Number(partido.away_score);

        });


        console.log("PARTIDOS EMPATADOS:");

        console.log(partidosEmpatados);


        // Mostrar encabezado y resumen
        resultadoEmpates.innerHTML = `

            <div class="resumen-empates">

                <h3>Partidos que terminaron en empate</h3>

                <p>
                    Se encontraron
                    <strong>${partidosEmpatados.length}</strong>
                    partidos empatados.
                </p>

            </div>

            <div class="contenedor-empates"></div>

        `;


        const contenedorEmpates =
            document.querySelector(".contenedor-empates");


        // Mostrar cada partido
        partidosEmpatados.forEach(function(partido, indice) {


            contenedorEmpates.innerHTML += `

                <div class="tarjeta-empate">

                    <div class="numero-empate">

                        ${indice + 1}

                    </div>


                    <div class="informacion-empate">

                        <h3>

                            ${partido.home_team_name_en}

                            <span>vs</span>

                            ${partido.away_team_name_en}

                        </h3>


                        <div class="marcador-empate">

                            ${partido.home_score}

                            <span>-</span>

                            ${partido.away_score}

                        </div>


                        <p>

                            <strong>Fecha:</strong>

                            ${partido.local_date}

                        </p>


                        <p>

                            <strong>Grupo / Ronda:</strong>

                            ${partido.group}

                        </p>


                        <p>

                            <strong>Jornada:</strong>

                            ${partido.matchday}

                        </p>


                        <p>

                            <strong>Estadio ID:</strong>

                            ${partido.stadium_id}

                        </p>

                    </div>

                </div>

            `;

        });

    })


    .catch(function(error) {


        console.error(

            "Error al cargar los partidos:",

            error

        );


        resultadoEmpates.innerHTML = `

            <div class="error">

                <p>

                    Ocurrió un error al cargar
                    los partidos.

                </p>

            </div>

        `;

    });