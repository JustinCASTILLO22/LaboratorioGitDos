const resultadoGoleadas =
    document.getElementById("resultadoGoleadas");


obtenerPartidos()
    .then(function(datos) {

        const partidos = datos.games;

        console.log("PARTIDOS RECIBIDOS PARA GOLEADAS:");

        console.log(partidos);


        // Filtrar solamente partidos que ya terminaron
        const partidosFinalizados =
            partidos.filter(function(partido) {

                return partido.finished === "TRUE";

            });


        // Ordenar los partidos según la diferencia de goles
        partidosFinalizados.sort(function(a, b) {

            const diferenciaA =
                Math.abs(
                    Number(a.home_score) -
                    Number(a.away_score)
                );


            const diferenciaB =
                Math.abs(
                    Number(b.home_score) -
                    Number(b.away_score)
                );


            return diferenciaB - diferenciaA;

        });


        console.log(
            "PARTIDOS ORDENADOS POR DIFERENCIA DE GOLES:"
        );

        console.log(partidosFinalizados);


        // Mostrar el encabezado de los resultados
        resultadoGoleadas.innerHTML = `

            <div class="resumen-goleadas">

                <h3>
                    Partidos con mayor diferencia de goles
                </h3>

                <p>
                    Se analizaron
                    <strong>
                        ${partidosFinalizados.length}
                    </strong>
                    partidos finalizados.
                </p>

            </div>

        `;


        // Mostrar cada partido como una tarjeta
        partidosFinalizados.forEach(
            function(partido, indice) {


                const diferencia =
                    Math.abs(
                        Number(partido.home_score) -
                        Number(partido.away_score)
                    );


                resultadoGoleadas.innerHTML += `

                    <div class="tarjeta-goleada">

                        <h3>
                            Goleada ${indice + 1}
                        </h3>


                        <div class="equipos">

                            ${partido.home_team_name_en}

                            vs

                            ${partido.away_team_name_en}

                        </div>


                        <div class="marcador">

                            ${partido.home_score}

                            -

                            ${partido.away_score}

                        </div>


                        <div class="diferencia">

                            Diferencia de goles:
                            ${diferencia}

                        </div>


                        <div class="info-partido">

                            <p>

                                <strong>
                                    Fecha:
                                </strong>

                                ${partido.local_date}

                            </p>


                            <p>

                                <strong>
                                    Grupo / Ronda:
                                </strong>

                                ${partido.group}

                            </p>


                            <p>

                                <strong>
                                    Jornada:
                                </strong>

                                ${partido.matchday}

                            </p>


                            <p>

                                <strong>
                                    Estado:
                                </strong>

                                ${partido.finished}

                            </p>

                        </div>

                    </div>

                `;

            }
        );

    })
    .catch(function(error) {

        console.error(
            "Error al cargar los partidos:",
            error
        );


        resultadoGoleadas.innerHTML = `

            <div class="tarjeta-goleada">

                <h3>
                    Error
                </h3>

                <p>
                    Ocurrió un error al cargar
                    los partidos.
                </p>

            </div>

        `;

    });