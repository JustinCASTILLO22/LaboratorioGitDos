const BASE_URL = "https://worldcup26.ir";

function obtenerEquipos() {

    return fetch(`${BASE_URL}/get/teams`)
        .then(function(respuesta) {

            if (!respuesta.ok) {
                throw new Error("Error al obtener los equipos");
            }

            return respuesta.json();

        })
        .then(function(datos) {

            return datos;

        })
        .catch(function(error) {

            console.error("Error al obtener los equipos:", error);

            return [];
        });
}


function obtenerPartidos() {

    return fetch(`${BASE_URL}/get/games`)
        .then(function(respuesta) {

            if (!respuesta.ok) {
                throw new Error("Error al obtener los partidos");
            }

            return respuesta.json();

        })
        .then(function(datos) {

            return datos;

        })
        .catch(function(error) {

            console.error("Error al obtener los partidos:", error);

            return [];
        });
}


function obtenerEstadios() {

    return fetch(`${BASE_URL}/get/stadiums`)
        .then(function(respuesta) {

            if (!respuesta.ok) {
                throw new Error("Error al obtener los estadios");
            }

            return respuesta.json();

        })
        .then(function(datos) {

            return datos;

        })
        .catch(function(error) {

            console.error("Error al obtener los estadios:", error);

            return [];
        });
}