const resultadoEstadios =
    document.getElementById("resultadoEstadios");


obtenerEstadios()
    .then(function(datos) {

        const estadios = datos.stadiums;


        console.log("ESTADIOS RECIBIDOS:");

        console.log(estadios);


        // Mostrar resumen
        resultadoEstadios.innerHTML = `

            <div class="resumen-estadios">

                <h3>Estadios del Mundial 2026</h3>

                <p>

                    Se encontraron

                    <strong>
                        ${estadios.length}
                    </strong>

                    estadios.

                </p>

            </div>


            <div class="contenedor-estadios"></div>

        `;


        const contenedorEstadios =
            document.querySelector(".contenedor-estadios");


        // Mostrar cada estadio
        estadios.forEach(function(estadio, indice) {


            contenedorEstadios.innerHTML += `

                <div class="tarjeta-estadio">


                    <div class="numero-estadio">

                        ${indice + 1}

                    </div>


                    <div class="informacion-estadio">


                        <h3>

                            ${estadio.name_en}

                        </h3>


                        <p>

                            <strong>
                                Ciudad:
                            </strong>

                            ${estadio.city_en}

                        </p>


                        <p>

                            <strong>
                                País:
                            </strong>

                            ${estadio.country_en}

                        </p>


                        <p>

                            <strong>
                                Capacidad:
                            </strong>

                            ${estadio.capacity.toLocaleString()}

                            espectadores

                        </p>


                        <p>

                            <strong>
                                Región:
                            </strong>

                            ${estadio.region}

                        </p>


                        <p>

                            <strong>
                                Nombre FIFA:
                            </strong>

                            ${estadio.fifa_name}

                        </p>


                    </div>


                </div>

            `;

        });

    })


    .catch(function(error) {


        console.error(

            "Error al cargar los estadios:",

            error

        );


        resultadoEstadios.innerHTML = `

            <div class="error">

                <p>

                    Ocurrió un error al cargar
                    los estadios.

                </p>

            </div>

        `;

    });