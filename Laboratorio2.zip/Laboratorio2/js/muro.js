const resultadoMuro =
    document.getElementById("resultadoMuro");


let equipos = [];

let partidos = [];


obtenerEquipos()
    .then(function(datos) {

        equipos = datos.teams;

        console.log("EQUIPOS RECIBIDOS PARA EL MURO:");

        console.log(equipos);


        return obtenerPartidos();

    })
    .then(function(datos) {

        partidos = datos.games;

        console.log("PARTIDOS RECIBIDOS PARA EL MURO:");

        console.log(partidos);


        // Obtener solamente los partidos finalizados
        const partidosFinalizados =
            partidos.filter(function(partido) {

                return partido.finished === "TRUE";

            });


        // Crear estadísticas defensivas
        const estadisticas = [];


        equipos.forEach(function(equipo) {

            let partidosJugados = 0;

            let golesRecibidos = 0;


            partidosFinalizados.forEach(function(partido) {


                // Si el equipo juega como local
                if (
                    String(partido.home_team_id) ===
                    String(equipo.id)
                ) {

                    partidosJugados++;

                    golesRecibidos +=
                        Number(partido.away_score);

                }


                // Si el equipo juega como visitante
                if (
                    String(partido.away_team_id) ===
                    String(equipo.id)
                ) {

                    partidosJugados++;

                    golesRecibidos +=
                        Number(partido.home_score);

                }

            });


            // Agregar solamente equipos
            // que hayan jugado partidos
            if (partidosJugados > 0) {

                estadisticas.push({

                    nombre:
                        equipo.name_en,

                    partidos:
                        partidosJugados,

                    golesRecibidos:
                        golesRecibidos

                });

            }

        });


        // Ordenar de menor a mayor
        // cantidad de goles recibidos
        estadisticas.sort(function(a, b) {

            return a.golesRecibidos -
                   b.golesRecibidos;

        });


        console.log(
            "ESTADISTICAS DEFENSIVAS:"
        );

        console.log(estadisticas);


        // Mostrar resumen
        resultadoMuro.innerHTML = `

            <div class="resumen-muro">

                <h3>
                    Equipos con mejor defensa
                </h3>

                <p>

                    Se analizaron

                    <strong>
                        ${partidosFinalizados.length}
                    </strong>

                    partidos finalizados.

                </p>

            </div>

        `;


        // Mostrar cada equipo
        estadisticas.forEach(
            function(equipo, indice) {


                resultadoMuro.innerHTML += `

                    <div class="tarjeta-muro">

                        <div class="posicion-muro">

                            ${indice + 1}

                        </div>


                        <div class="contenido-muro">

                            <h3>

                                ${equipo.nombre}

                            </h3>


                            <p>

                                Partidos jugados:

                                <strong>

                                    ${equipo.partidos}

                                </strong>

                            </p>


                            <p>

                                Goles recibidos:

                                <strong>

                                    ${equipo.golesRecibidos}

                                </strong>

                            </p>

                        </div>

                    </div>

                `;

            }
        );

    })
    .catch(function(error) {

        console.error(
            "Error al cargar los datos defensivos:",
            error
        );


        resultadoMuro.innerHTML = `

            <div class="tarjeta-error">

                <h3>
                    Error
                </h3>

                <p>

                    Ocurrió un error al cargar
                    las estadísticas defensivas.

                </p>

            </div>

        `;

    });