const selectorEquipo = document.getElementById("equipo");
const resultado = document.getElementById("resultado");

let equipos = [];
let partidos = [];
let estadios = [];


obtenerEquipos()
    .then(function(datos) {

        equipos = datos.teams;

        equipos.forEach(function(equipo) {

            const opcion = document.createElement("option");

            opcion.value = equipo.id;

            opcion.textContent = equipo.name_en;

            selectorEquipo.appendChild(opcion);

        });

    });


obtenerPartidos()
    .then(function(datos) {

        partidos = datos.games;

        console.log("Partidos cargados:", partidos.length);

    });


obtenerEstadios()
    .then(function(datos) {

        estadios = datos.stadiums;

        console.log("Estadios cargados:", estadios.length);

    });


selectorEquipo.addEventListener("change", function() {

    const idEquipoSeleccionado = selectorEquipo.value;

    const nombreEquipoSeleccionado =
        selectorEquipo.options[selectorEquipo.selectedIndex].text;


    if (idEquipoSeleccionado === "") {

        resultado.innerHTML = "";

        return;

    }


    const partidosEquipo = partidos.filter(function(partido) {

        return String(partido.home_team_id) === String(idEquipoSeleccionado)
            || String(partido.away_team_id) === String(idEquipoSeleccionado);

    });


    console.log("Equipo seleccionado:", nombreEquipoSeleccionado);

    console.log("ID del equipo:", idEquipoSeleccionado);

    console.log("Partidos encontrados:", partidosEquipo);


    let htmlPartidos = "";


    partidosEquipo.forEach(function(partido) {

        const estadio = estadios.find(function(estadio) {

            return String(estadio.id) === String(partido.stadium_id);

        });


        let informacionEstadio = "";


        if (estadio) {

            informacionEstadio = `

                <p>
                    <strong>Estadio:</strong>
                    ${estadio.name_en}
                </p>

                <p>
                    <strong>Ciudad:</strong>
                    ${estadio.city_en}
                </p>

                <p>
                    <strong>País:</strong>
                    ${estadio.country_en}
                </p>

                <p>
                    <strong>Capacidad:</strong>
                    ${estadio.capacity.toLocaleString()}
                    espectadores
                </p>

            `;

        } else {

            informacionEstadio = `

                <p>
                    <strong>Estadio:</strong>
                    Información no disponible
                </p>

            `;

        }


        htmlPartidos += `

            <div class="partido">

                <h4>
                    ${partido.home_team_name_en}
                    vs
                    ${partido.away_team_name_en}
                </h4>

                <p>
                    <strong>Marcador:</strong>
                    ${partido.home_score} -
                    ${partido.away_score}
                </p>

                <p>
                    <strong>Fecha:</strong>
                    ${partido.local_date}
                </p>

                <p>
                    <strong>Grupo / Ronda:</strong>
                    ${partido.group}
                </p>

                <p>
                    <strong>Jornada:</strong>
                    ${partido.matchday}
                </p>

                ${informacionEstadio}

                <p>
                    <strong>Estado:</strong>
                    ${partido.finished}
                </p>

            </div>

        `;

    });


    resultado.innerHTML = `

        <div class="equipo-seleccionado">

            <h3>Equipo seleccionado</h3>

            <p>
                <strong>Nombre:</strong>
                ${nombreEquipoSeleccionado}
            </p>

            <p>
                <strong>ID:</strong>
                ${idEquipoSeleccionado}
            </p>

        </div>


        <h3>Partidos del equipo</h3>

        <p>
            Se encontraron
            <strong>${partidosEquipo.length}</strong>
            partidos.
        </p>


        <div class="lista-partidos">

            ${htmlPartidos}

        </div>

    `;

});